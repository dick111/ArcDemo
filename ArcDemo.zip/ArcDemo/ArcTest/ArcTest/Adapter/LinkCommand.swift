//
//  LinkCommand.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class LinkCommand: Factory {

    var cell: LinkCell?
    
    override func getCell(criteria: Criteria) -> UITableViewCell? {
        
        var cell = criteria.tableView?.dequeueReusableCell(withIdentifier: criteria.reuseIdentifier) as? LinkCell
        if cell == nil {
            cell = LinkCell.init(style: .default, reuseIdentifier: criteria.reuseIdentifier)
        }
        cell?.setDataModel(model: criteria.dataModel!)
        cell?.linkClickBlock = { (link) in
            let htmlVC = HtmlViewController()
            htmlVC.urlStr = criteria.dataModel!.link
            criteria.viewController?.navigationController?.pushViewController(htmlVC, animated: true)
        }
        return cell!
    }
}
