//
//  TextImageCommand.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class TextImageCommand: Factory {

    var cell: TextImageCell?
    
    override func getCell(criteria: Criteria) -> UITableViewCell? {
        
        var cell = criteria.tableView?.dequeueReusableCell(withIdentifier: criteria.reuseIdentifier) as? TextImageCell
        if cell == nil {
            cell = TextImageCell.init(style: .default, reuseIdentifier: criteria.reuseIdentifier)
        }
        cell?.setDataModel(model: criteria.dataModel!)
        return cell!
    }
}
