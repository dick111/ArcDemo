//
//  Criteria.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class Criteria: NSObject {

    var tableView: UITableView?
    var reuseIdentifier: String = ""
    var height: CGFloat = 120
    var viewController: UIViewController?
    var dataModel: DataModel? {
        didSet {
            let h = dataModel?.content.getHeightWith(width: kScreen_width - 30, fontSize: 16)
            height = h!
        }
    }
    
    
}
