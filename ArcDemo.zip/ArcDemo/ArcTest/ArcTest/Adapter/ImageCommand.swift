//
//  ImageCommand.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class ImageCommand: Factory {
    
    var cell: ImageCell?
    
    override func getCell(criteria: Criteria) -> UITableViewCell? {
        
        var cell = criteria.tableView?.dequeueReusableCell(withIdentifier: criteria.reuseIdentifier) as? ImageCell
        if cell == nil {
            cell = ImageCell.init(style: .default, reuseIdentifier: criteria.reuseIdentifier)
        }
        cell?.setDataModel(model: criteria.dataModel!)
        return cell!
    }
}
