//
//  Factory.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class Factory: NSObject {

    var dict = [String:Any]()
    required override init() {
        super.init()
        dict = ["text":"TextCommand",
                "text-img":"TextImageCommand",
                "img":"ImageCommand",
                "text-link":"LinkCommand"]
    }
    
    func getCell(criteria: Criteria) -> UITableViewCell? {
        let workName = Bundle.main.infoDictionary?["CFBundleExecutable"] as! String
        let str = dict[criteria.reuseIdentifier] as! String
        let command = NSClassFromString("\(workName).\(str)") as! Factory.Type
        let cls = command.init()
        return cls.getCell(criteria: criteria)
    }
}
