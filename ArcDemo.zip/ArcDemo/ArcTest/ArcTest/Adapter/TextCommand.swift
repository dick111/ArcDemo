//
//  TextCommand.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class TextCommand: Factory {

    var cell: HomeCell?
    
    override func getCell(criteria: Criteria) -> UITableViewCell? {
        
        var cell = criteria.tableView?.dequeueReusableCell(withIdentifier: criteria.reuseIdentifier) as? HomeCell
        if cell == nil {
            cell = HomeCell.init(style: .default, reuseIdentifier: criteria.reuseIdentifier)
        }
        cell?.setDataModel(model: criteria.dataModel!)
        return cell!
    }
}
