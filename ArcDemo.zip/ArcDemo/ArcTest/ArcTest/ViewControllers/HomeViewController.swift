//
//  HomeViewController.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

let kScreen_width = UIScreen.main.bounds.size.width
let kScreen_height = UIScreen.main.bounds.size.height
class HomeViewController: UIViewController {

    //数据加载器
    let loader = DataEntryLoader()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        self.navigationItem.title = "首页"
        loader.loadData()
        
        self.view.addSubview(self.tableView)
        self.tableView.frame = self.view.frame
    }
    
    lazy var tableView: UITableView = {
        let table = UITableView.init(frame: CGRect.zero, style: .grouped)
        table.backgroundColor = .clear
        table.estimatedRowHeight = 0
        table.estimatedSectionFooterHeight = 0
        table.estimatedSectionHeaderHeight = 0
        table.delegate = self
        table.dataSource = self
        return table
    }()

}

extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return loader.entries.count
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        
        return loader.heights[indexPath.section]
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return CGFloat.leastNormalMagnitude
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let factory = Factory()
        let criteria = Criteria()
        let dataModel = loader.entries[indexPath.section]
        criteria.tableView = tableView
        criteria.reuseIdentifier = dataModel.type
        criteria.dataModel = dataModel
        criteria.viewController = self
        return factory.getCell(criteria: criteria)!
    }

    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let dataModel = loader.entries[indexPath.section]
        let detailVC = DetailViewController()
        detailVC.dataModel = dataModel
        self.navigationController?.pushViewController(detailVC, animated: true)
    }
}
