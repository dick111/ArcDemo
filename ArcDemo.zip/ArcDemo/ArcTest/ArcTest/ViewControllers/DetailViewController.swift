//
//  DetailViewController.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit
import JXPhotoBrowser

class DetailViewController: UIViewController {

    var dataModel: DataModel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = .white
        self.navigationItem.title = "详情页"
        
        self.view.addSubview(self.scrollView)
        self.scrollView.frame = CGRect.init(x: 0, y: 88, width: kScreen_width, height: kScreen_height - 88)
        configData()
    }
    

    func configData() {
        var firstPoint: CGFloat = 0
        if self.dataModel.content.count > 0 {
            let label = UILabel()
            self.scrollView.addSubview(label)
            label.text = self.dataModel.content
            label.font = UIFont.systemFont(ofSize: 16)
            label.textColor = UIColor.lightGray
            label.numberOfLines = 0
            let labelH = self.dataModel.content.getHeightWith(width: kScreen_width - 30, fontSize: 16)
            label.frame = CGRect.init(x: 15, y: 15, width: kScreen_width - 30, height: labelH)
            firstPoint = 15 + labelH
            self.scrollView.contentSize = CGSize.init(width: kScreen_width, height: firstPoint)
        }
        if self.dataModel.type == "text-link" {
            let linkBtn = UIButton(type: .custom)
            linkBtn.setTitleColor(UIColor.blue, for: .normal)
            linkBtn.setTitle(self.dataModel.link, for: .normal)
            self.scrollView.addSubview(linkBtn)
            linkBtn.frame = CGRect.init(x: 15, y: 15 + firstPoint, width: 180, height: 20)
            firstPoint = linkBtn.frame.origin.y + 20
            self.scrollView.contentSize = CGSize.init(width: kScreen_width, height: firstPoint)
            linkBtn.addTarget(self, action: #selector(linkClick), for: .touchUpInside)
        }
        if self.dataModel.imgUrls.count > 0 {
            var imgHeight: CGFloat = 0
            if self.dataModel.type == "img" {
                imgHeight = 257 * 446 / kScreen_width
            } else {
                imgHeight = 271 * 446 / kScreen_width
            }
            var count = 0
            var totalHeight: CGFloat = 0
            for urlStr in self.dataModel.imgUrls {
                let imgView = UIImageView()
                imgView.isUserInteractionEnabled = true
                imgView.tag = count + 1
                self.scrollView.addSubview(imgView)
                imgView.sd_setImage(with: URL(string: urlStr), completed: nil)
                imgView.frame = CGRect.init(x: 15, y: 15 + firstPoint + imgHeight * CGFloat(count), width: kScreen_width - 30, height: imgHeight)
                count += 1
                totalHeight = CGFloat(count) * imgHeight
                
                //添加点击事件
                let tap = UITapGestureRecognizer.init(target: self, action: #selector(photoClick(tap:)))
                imgView.addGestureRecognizer(tap)
            }
            self.scrollView.contentSize = CGSize.init(width: kScreen_width, height: firstPoint + 15 + totalHeight)
        }
    }

    @objc func photoClick(tap: UITapGestureRecognizer) {
        
        let browser = JXPhotoBrowser()
        
        browser.numberOfItems = {
            self.dataModel.imgUrls.count
        }
        
        browser.reloadCellAtIndex = { context in
            let url = self.dataModel.imgUrls[context.index]
            let browserCell = context.cell as? JXPhotoBrowserImageCell
            browserCell?.index = context.index
            browserCell?.imageView.sd_setImage(with: URL(string: url), completed: nil)
        }
        
        browser.pageIndex = tap.view!.tag - 1
        browser.show()
    }
    
    @objc func linkClick() {
        let htmlVC = HtmlViewController()
        htmlVC.urlStr = self.dataModel.link
        self.navigationController?.pushViewController(htmlVC, animated: true)
    }
    
    lazy var scrollView: UIScrollView = {
        let scrollView = UIScrollView()
        scrollView.backgroundColor = .clear
        return scrollView
    }()
}
