//
//  HtmlViewController.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit
import WebKit

class HtmlViewController: UIViewController {

    var urlStr: String = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let webView = WKWebView.init(frame: self.view.frame)
        
        self.view.addSubview(webView)
        webView.load(URLRequest(url: URL(string: self.urlStr)!))
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
