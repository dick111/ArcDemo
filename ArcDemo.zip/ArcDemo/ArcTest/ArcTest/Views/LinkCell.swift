//
//  LinkCell.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class LinkCell: UITableViewCell {

    var link: String = ""
    var linkClickBlock: ((String) -> Void)?
    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.darkGray
        self.selectionStyle = .none
        configUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setDataModel(model: DataModel) {
        
        self.label.text = model.content
        self.button.setTitle(model.link, for: .normal)
        link = model.link
        let contentH = model.content.getHeightWith(width: kScreen_width - 30, fontSize: 16)
        self.label.frame = CGRect.init(x: 15, y: 10, width: kScreen_width - 30, height: contentH)
        self.button.frame = CGRect.init(x: 15, y: 20 + contentH, width: 180, height: 20)
    }
    
    @objc func linkClick() {
        if (self.linkClickBlock != nil) {
            self.linkClickBlock!(link)
        }
    }
    
    func configUI() {
        self.contentView.addSubview(self.label)
        self.contentView.addSubview(self.button)
    }
    
    lazy var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.lightGray
        label.numberOfLines = 0
        return label
    }()
    
    lazy var button: UIButton = {
        let btn = UIButton(type: .custom)
        btn.setTitleColor(UIColor.blue, for: .normal)
        btn.addTarget(self, action: #selector(linkClick), for: .touchUpInside)
        return btn
    }()
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
