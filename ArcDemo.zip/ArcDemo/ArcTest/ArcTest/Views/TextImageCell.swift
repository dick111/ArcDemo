//
//  TextImageCell.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit
import SDWebImage
class TextImageCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.darkGray
        self.selectionStyle = .none
        configUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    
    func configUI() {
        self.contentView.addSubview(self.label)
    }
    
    func setDataModel(model: DataModel) {
        self.label.text = model.content
        let height = model.content.getHeightWith(width: kScreen_width - 30, fontSize: 16)
        self.label.frame = CGRect.init(x: 15, y: 10, width: kScreen_width - 30, height: height)
        var imgHeight = 271 * 446 / kScreen_width
        if model.imgUrls.count > 1 {
            let width = (kScreen_width - 30) / 3
            imgHeight = 271 * width / 446
            if imgHeight > 220 {imgHeight = 220}
            var count: CGFloat = 0
            //最多显示三张
            for imgUrlStr in model.imgUrls {
                guard count < 3 else {break}
                let imgView = UIImageView()
                self.contentView.addSubview(imgView)
                imgView.contentMode = .scaleAspectFit
                imgView.sd_setImage(with: URL(string: imgUrlStr), completed: nil)
                imgView.frame = CGRect.init(x: 15 + (kScreen_width - 30) / 3 * count, y: 20 + height, width: (kScreen_width - 30) / CGFloat(3), height: imgHeight)
                count += 1
            }
        } else {
            if imgHeight > 220 {imgHeight = 220}
            let imgView = UIImageView()
            self.contentView.addSubview(imgView)
            imgView.contentMode = .scaleAspectFit
            imgView.sd_setImage(with: URL(string: model.imgUrls.first!), completed: nil)
            imgView.frame = CGRect.init(x: 15, y: 20 + height, width: (kScreen_width - 30), height: imgHeight)
        }
                
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    lazy var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.lightGray
        label.numberOfLines = 0
        return label
    }()
    
}
