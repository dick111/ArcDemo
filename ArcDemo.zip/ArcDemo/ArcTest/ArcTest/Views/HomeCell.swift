//
//  HomeCell.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class HomeCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.darkGray
        self.selectionStyle = .none
        self.configUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func configUI() {
        self.contentView.addSubview(self.label)
    }
    
    func setDataModel(model: DataModel) {
        self.label.text = model.content
        let height = model.content.getHeightWith(width: kScreen_width - 30, fontSize: 16)
        self.label.frame = CGRect.init(x: 15, y: 10, width: kScreen_width - 30, height: height)
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    lazy var label: UILabel = {
        let label = UILabel()
        label.font = UIFont.systemFont(ofSize: 16)
        label.textColor = UIColor.lightGray
        label.numberOfLines = 0
        return label
    }()
    
    
}
