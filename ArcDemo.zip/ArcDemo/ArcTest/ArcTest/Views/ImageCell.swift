//
//  ImageCell.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class ImageCell: UITableViewCell {

    override init(style: UITableViewCell.CellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        self.backgroundColor = UIColor.darkGray
        self.selectionStyle = .none
        configUI()
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setDataModel(model: DataModel) {
        self.imgView.sd_setImage(with: URL(string: model.imgUrls.first!), completed: nil)
        var imgHeight = 257 * 446 / kScreen_width
        var oneImage = true
        if model.imgUrls.count > 1 {
            let width = (kScreen_width - 30) / 3
            imgHeight = 257 * width / 446
            oneImage = false
        }
        if imgHeight > 220 {imgHeight = 220}
        imgView.frame = CGRect.init(x: 15, y: 10, width: (kScreen_width - 30) / (oneImage ? CGFloat(1) : CGFloat(3)), height: imgHeight)
    }
    
    func configUI() {
        self.contentView.addSubview(self.imgView)
    }
    
    lazy var imgView: UIImageView = {
        let view = UIImageView()
        view.contentMode = .scaleAspectFit
        return view
    }()
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
