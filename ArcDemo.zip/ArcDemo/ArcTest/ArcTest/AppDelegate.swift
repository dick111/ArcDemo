//
//  AppDelegate.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/27.
//

import UIKit

@main
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        window = UIWindow(frame: UIScreen.main.bounds)
        window?.makeKeyAndVisible()
        let nav = UINavigationController.init(rootViewController: HomeViewController())
        window?.rootViewController = nav
        
        return true
    }




}

