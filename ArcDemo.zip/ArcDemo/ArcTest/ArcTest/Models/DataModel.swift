//
//  DataModel.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import UIKit

class DataModel: NSObject {

    let id: String
    let type: String
    let content: String
    let imgUrls: [String]
    let link: String
    
    init(id: String? = "", type: String? = "", content: String? = "", imgUrls: [String]? = [], link: String? = "") {
        self.id = id ?? ""
        self.type = type ?? ""
        self.content = content ?? ""
        self.imgUrls = imgUrls ?? [""]
        self.link = link ?? ""
    }
    
}
