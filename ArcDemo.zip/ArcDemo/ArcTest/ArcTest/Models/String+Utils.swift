//
//  String+Utils.swift
//  ArcTest
//
//  Created by 梁志基 on 2022/2/28.
//

import Foundation
import UIKit

extension String {
    
    func getHeightWith(width: CGFloat, fontSize: CGFloat) -> CGFloat {
        
        return self.boundingRect(with:CGSize(width: width, height:CGFloat(MAXFLOAT)), options: .usesLineFragmentOrigin, attributes: [.font:UIFont.systemFont(ofSize: fontSize)], context:nil).size.height
        
    }
}
